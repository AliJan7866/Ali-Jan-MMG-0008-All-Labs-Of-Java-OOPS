class Lab3Task3 {
    public static void main (String[]args){
        int [][] matrix = {
            {12,13,15,16},
            {11,110,121,17},
            {17,18,100,21}
        };
        for (int i=0; i<matrix.length; i++){
            for (int j=0; j<matrix[i].length; j++){
                if (matrix[i][j] %2==0){
                    matrix[i][j] = matrix[i][j] /2;
                }
            }
        }
        for (int i=0; i<matrix.length; i++) {
            for (int j=0; j<matrix[i].length; j++){
                if (matrix[i][j] %2 !=0){
                    System.out.println(matrix[i][j]);
                }
            }
        }
        int sumEven = 0;
        for (int i=0; i<matrix.length; i++) {
            for (int j=0; j<matrix[i].length; j++){
                if (matrix[i][j] %2 == 0){
                    sumEven += matrix[i][j];
                }
            }
        }
        System.out.println("Sum of even numbers:" + sumEven);
    }
}