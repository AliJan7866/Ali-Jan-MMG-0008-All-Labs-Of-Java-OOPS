import java.util.Scanner;

class Lab3Task5 {
    public static void main(String[] args) {
        final int rows = 5, cols = 5;
        boolean[][] seats = new boolean[rows][cols];
        Scanner scanner = new Scanner(System.in);
        int choice, r, c;

        do {
            System.out.println("1. Display available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    for (int i = 0; i < rows; i++) {
                        for (int j = 0; j < cols; j++) {
                            if (seats[i][j] == false) {
                                System.out.print("o");
                            } else {
                                System.out.print("X");
                            }
                        }
                        System.out.println();
                    }
                    break;

                case 2:
                    System.out.print("Enter row number (0-" + (rows - 1) + "): ");
                    r = scanner.nextInt();
                    System.out.print("Enter column number (0-" + (cols - 1) + "): ");
                    c = scanner.nextInt();

                    if (r >= 0 && r < rows && c >= 0 && c < cols) {
                        if (seats[r][c] == false) {
                            seats[r][c] = true;
                            System.out.println("Seat reserved.");
                        } else {
                            System.out.println("Seat already reserved.");
                        }
                    } else {
                        System.out.println("Invalid seat coordinates.");
                    }
                    break;

                case 3:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } while (choice != 3);

        scanner.close();
    }
}
